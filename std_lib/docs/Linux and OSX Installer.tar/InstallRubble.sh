#!/bin/sh

# This script "installs" Rubble on Linux or OSX.

if uname -s | grep -i "darwin" >/dev/null; then
	dir=${0%/*}
	if [ -d "$dir" ]; then
		cd "$dir"
	fi
	
	cp "./darwin/launch-rubble" "./../rubble"
	
	chmod +x "./darwin/rubble"
else
	# If not OSX assume Linux
	cp "./linux/rubble" "./../rubble"
fi

rm "./../rubble.exe"

chmod +x "./../rubble"

chmod +x "./webUI/browser"
